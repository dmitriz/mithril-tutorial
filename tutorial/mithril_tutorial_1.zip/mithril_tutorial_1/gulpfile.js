'use strict'

var gulp = require('gulp')
var watch = require('gulp-watch')
var browserify = require('gulp-browserify')

gulp.task('scripts', function() {
	watch(['./src/*.js', './src/**/*.js'], {ignoreInitial: false}, function  (){
		console.log('running scripts...')
		gulp.src('./src/index.js')
			.pipe(browserify({
				insertGlobals : true,
				debug : true
			}))
			.pipe(gulp.dest('build/'))	
	})
})

gulp.task('html', function() {
	watch(['./src/*.html'], {ignoreInitial: false}, function() {
		console.log('running html...')
		gulp.src('src/*.html')
			.pipe(gulp.dest('build/'))
	})
})

gulp.task('json', function() {
	watch(['./src/**/*.json'], {ignoreInitial: false}, function  (){
		console.log('running json...')
		gulp.src('src/model/data.json')
			.pipe(gulp.dest('build/'))
	})
})

gulp.task('css', function  (){
	watch(['./src/*.css'], {ignoreInitial: false}, function (){
		console.log('running css...')
		gulp.src('src/*.css')
			.pipe(gulp.dest('build/'))
	})
})

gulp.task('default', ['scripts', 'html', 'json', 'css'])